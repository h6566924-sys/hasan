package com.rafiki.ai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint as AndroidPaint
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private const val PREFS = "rafiki_store_v1"
private const val KEY_CHATS = "chats"
private const val KEY_KNOWLEDGE = "knowledge"
private const val KEY_MEMORY = "memory"
private const val KEY_SERVICES = "services"
private const val KEY_ENGINES = "engines"
private const val KEY_SETTINGS = "settings"

private data class ChatMessage(val role: String, val text: String, val time: Long = System.currentTimeMillis())
private data class Chat(val id: String, var title: String, val messages: MutableList<ChatMessage> = mutableListOf())
private data class KnowledgeChunk(val source: String, val text: String)
private data class MemoryItem(val key: String, val value: String)
private data class RafikiService(val name: String, val trigger: String, val code: String, val enabled: Boolean = true)
private data class RafikiEngine(val name: String, val type: String, val description: String, val code: String, val enabled: Boolean = true)

private class Store(context: Context) {
    private val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun saveChats(chats: List<Chat>) {
        val a = JSONArray()
        chats.forEach { c ->
            val o = JSONObject().apply {
                put("id", c.id); put("title", c.title)
                val m = JSONArray(); c.messages.forEach { msg ->
                    m.put(JSONObject().apply { put("role", msg.role); put("text", msg.text); put("time", msg.time) })
                }
                put("messages", m)
            }
            a.put(o)
        }
        p.edit().putString(KEY_CHATS, a.toString()).apply()
    }

    fun loadChats(): MutableList<Chat> {
        val out = mutableListOf<Chat>()
        val raw = p.getString(KEY_CHATS, "[]") ?: "[]"
        val a = JSONArray(raw)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val c = Chat(o.getString("id"), o.getString("title"))
            val m = o.optJSONArray("messages") ?: JSONArray()
            for (j in 0 until m.length()) {
                val x = m.getJSONObject(j)
                c.messages.add(ChatMessage(x.getString("role"), x.getString("text"), x.optLong("time")))
            }
            out.add(c)
        }
        return out
    }

    fun saveKnowledge(items: List<KnowledgeChunk>) {
        val a = JSONArray(); items.forEach { a.put(JSONObject().apply { put("source", it.source); put("text", it.text) }) }
        p.edit().putString(KEY_KNOWLEDGE, a.toString()).apply()
    }
    fun loadKnowledge(): MutableList<KnowledgeChunk> {
        val out = mutableListOf<KnowledgeChunk>(); val a = JSONArray(p.getString(KEY_KNOWLEDGE, "[]") ?: "[]")
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); out.add(KnowledgeChunk(o.getString("source"), o.getString("text"))) }
        return out
    }

    fun saveMemory(items: List<MemoryItem>) {
        val a = JSONArray(); items.forEach { a.put(JSONObject().apply { put("key", it.key); put("value", it.value) }) }
        p.edit().putString(KEY_MEMORY, a.toString()).apply()
    }
    fun loadMemory(): MutableList<MemoryItem> {
        val out = mutableListOf<MemoryItem>(); val a = JSONArray(p.getString(KEY_MEMORY, "[]") ?: "[]")
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); out.add(MemoryItem(o.getString("key"), o.getString("value"))) }
        return out
    }

    fun saveServices(items: List<RafikiService>) {
        val a = JSONArray(); items.forEach { a.put(JSONObject().apply { put("name", it.name); put("trigger", it.trigger); put("code", it.code); put("enabled", it.enabled) }) }
        p.edit().putString(KEY_SERVICES, a.toString()).apply()
    }
    fun loadServices(): MutableList<RafikiService> {
        val out = mutableListOf<RafikiService>(); val a = JSONArray(p.getString(KEY_SERVICES, "[]") ?: "[]")
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); out.add(RafikiService(o.getString("name"), o.optString("trigger"), o.optString("code"), o.optBoolean("enabled", true))) }
        return out
    }

    fun saveEngines(items: List<RafikiEngine>) {
        val a = JSONArray(); items.forEach { a.put(JSONObject().apply { put("name", it.name); put("type", it.type); put("description", it.description); put("code", it.code); put("enabled", it.enabled) }) }
        p.edit().putString(KEY_ENGINES, a.toString()).apply()
    }
    fun loadEngines(): MutableList<RafikiEngine> {
        val out = mutableListOf<RafikiEngine>(); val a = JSONArray(p.getString(KEY_ENGINES, "[]") ?: "[]")
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); out.add(RafikiEngine(o.getString("name"), o.optString("type"), o.optString("description"), o.optString("code"), o.optBoolean("enabled", true))) }
        return out
    }

    fun saveSettings(dark: Boolean, activeEngine: String) {
        p.edit().putString(KEY_SETTINGS, JSONObject().apply { put("dark", dark); put("engine", activeEngine) }.toString()).apply()
    }
    fun loadSettings(): Pair<Boolean, String> {
        val o = JSONObject(p.getString(KEY_SETTINGS, "{}") ?: "{}"); return Pair(o.optBoolean("dark", true), o.optString("engine", "رفيقي المحلي"))
    }

    fun exportAll(): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("chats", JSONArray(p.getString(KEY_CHATS, "[]")))
        root.put("knowledge", JSONArray(p.getString(KEY_KNOWLEDGE, "[]")))
        root.put("memory", JSONArray(p.getString(KEY_MEMORY, "[]")))
        root.put("services", JSONArray(p.getString(KEY_SERVICES, "[]")))
        root.put("engines", JSONArray(p.getString(KEY_ENGINES, "[]")))
        root.put("settings", JSONObject(p.getString(KEY_SETTINGS, "{}") ?: "{}"))
        return root.toString(2)
    }

    fun importAll(json: String) {
        val root = JSONObject(json)
        p.edit()
            .putString(KEY_CHATS, root.optJSONArray("chats")?.toString() ?: "[]")
            .putString(KEY_KNOWLEDGE, root.optJSONArray("knowledge")?.toString() ?: "[]")
            .putString(KEY_MEMORY, root.optJSONArray("memory")?.toString() ?: "[]")
            .putString(KEY_SERVICES, root.optJSONArray("services")?.toString() ?: "[]")
            .putString(KEY_ENGINES, root.optJSONArray("engines")?.toString() ?: "[]")
            .putString(KEY_SETTINGS, root.optJSONObject("settings")?.toString() ?: "{}")
            .apply()
    }
}

private fun newChat(): Chat = Chat(System.currentTimeMillis().toString(), "محادثة جديدة")

private fun seedKnowledge(): MutableList<KnowledgeChunk> = mutableListOf(
    KnowledgeChunk("المعرفة المدمجة", "رفيقي AI مساعد محلي يعمل على الهاتف. يستطيع إدارة الذاكرة والمعرفة والملفات والخدمات والمحركات، ويعتمد على البحث المحلي ولا يعرض قاعدة المعرفة كاملة عند طرح سؤال محدد."),
    KnowledgeChunk("المعرفة المدمجة", "HTML هي لغة ترميز لبناء هيكل صفحات الويب. CSS لتنسيق العرض. JavaScript لإضافة التفاعل. Python لغة برمجة عامة. Kotlin لغة أساسية حديثة لتطوير تطبيقات Android الأصلية."),
    KnowledgeChunk("المعرفة المدمجة", "IndexedDB وSharedPreferences من حلول التخزين المحلي. Android يوفر File Picker وTextToSpeech وSpeechRecognizer وMediaProjection لخدمات الهاتف."),
    KnowledgeChunk("المعرفة المدمجة", "أكبر كوكب في المجموعة الشمسية هو المشتري. يتميّز بحجمه الكبير وبقعة حمراء عظيمة وعواصف قوية، وله عدد كبير من الأقمار."),
    KnowledgeChunk("المعرفة المدمجة", "عند تعلّم ملف، يقسم رفيقي النص إلى مقاطع متداخلة ويخزنها محليًا، ثم يسترجع المقاطع الأقرب للسؤال فقط بدل نسخ كل المعلومات إلى الإجابة."),
    KnowledgeChunk("المعرفة المدمجة", "مشروع Android الأصلي يمكن بناؤه إلى APK باستخدام Gradle مع Android SDK. Kotlin وJava مدعومتان لتطبيقات Android الأصلية."),
    KnowledgeChunk("المعرفة المدمجة", "يمكن تصدير بيانات رفيقي كنسخة احتياطية JSON تشمل المحادثات والمعرفة والذاكرة والخدمات والمحركات والإعدادات، ثم استيرادها لاحقًا."),
)

private fun normalize(s: String): List<String> = s.lowercase(Locale("ar")).replace("ـ", "").split(Regex("[^\\p{L}\\p{Nd}_]+" )).filter { it.length > 1 }

private fun searchKnowledge(question: String, items: List<KnowledgeChunk>, maxResults: Int = 3): List<KnowledgeChunk> {
    val q = normalize(question).toSet()
    if (q.isEmpty()) return emptyList()
    return items.map { item ->
        val words = normalize(item.text).toSet()
        val score = q.count { it in words } * 3 + q.count { t -> item.text.contains(t, ignoreCase = true) }
        item to score
    }.filter { it.second > 0 }.sortedByDescending { it.second }.take(maxResults).map { it.first }
}

private fun extractReplyFromService(service: RafikiService, input: String): String? {
    val triggers = service.trigger.split(',').map { it.trim() }.filter { it.isNotEmpty() }
    if (triggers.isNotEmpty() && triggers.none { input.contains(it, ignoreCase = true) }) return null
    val lines = service.code.lines()
    val reply = lines.firstOrNull { it.trim().startsWith("REPLY=", true) }?.substringAfter('=' )?.trim()
    if (reply != null) return reply.replace("{input}", input)
    return null
}

private fun localAnswer(input: String, knowledge: List<KnowledgeChunk>, memory: List<MemoryItem>, services: List<RafikiService>, engines: List<RafikiEngine>, engine: String): String {
    services.filter { it.enabled }.forEach { s -> extractReplyFromService(s, input)?.let { return it } }
    val trimmed = input.trim()
    if (trimmed.isEmpty()) return "اكتب رسالتك وسأحاول مساعدتك."
    if (trimmed.startsWith("/حفظ")) return "استخدم قسم الذاكرة لإضافة معلومة ثابتة عن المشروع أو تفضيلاتك."
    if (trimmed.startsWith("/تعلم")) return "افتح «تعلّم من ملف» واختر ملفًا نصيًا أو PDF. سيُفهرس محليًا."
    if (trimmed.contains("السلام") || trimmed.contains("مرحبا") || trimmed.contains("مرحب")) return "وعليكم السلام 👋 أنا رفيقي. كيف أساعدك؟"
    if (trimmed.contains("اسمك")) return "اسمي رفيقي AI. أنا نسخة محلية مصممة للعمل على الهاتف وإدارة المعرفة والذاكرة والخدمات والمحركات."
    if (trimmed.contains("أكبر") && trimmed.contains("كوكب")) {
        val hit = searchKnowledge("أكبر كوكب", knowledge, 1).firstOrNull()
        if (hit != null) return hit.text
    }
    val hits = searchKnowledge(trimmed, knowledge, 2)
    if (hits.isNotEmpty()) {
        return when (hits.size) {
            1 -> "بحسب المعرفة المحلية: ${hits[0].text}"
            else -> "بحسب المعرفة المحلية:\n\n• ${hits[0].text}\n\n• ${hits[1].text}"
        }
    }
    if (trimmed.contains("أنشئ") || trimmed.contains("اكتب كود") || trimmed.contains("كود")) {
        val customPrefix = engines.firstOrNull { it.name == engine }?.code?.lineSequence()?.firstOrNull { it.startsWith("PREFIX=", true) }?.substringAfter("=")?.trim().orEmpty()
        val prefix = customPrefix.ifBlank { "أستطيع إنشاء قوالب برمجية محليًا." }
        return "$prefix

مثال سريع:\n\n```kotlin\nfun main() {\n    println(\"مرحبًا من رفيقي\")\n}\n```\n\nالعقل النشط: $engine"
    }
    if (memory.isNotEmpty() && trimmed.contains("تذكر")) {
        return "لدي ذاكرة محلية تحتوي ${memory.size} عنصرًا. افتح قسم الذاكرة لإدارتها."
    }
    return "فهمت سؤالك: «$trimmed». لا أملك نموذجًا لغويًا مولّدًا مضمّنًا داخل هذا الإصدار، لذلك أجيب محليًا من القواعد والمعرفة التي أضفتها. يمكنك توسيعي بإضافة عقل أو محرك أو خدمة من قسم الإدارة."
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent { RafikiApp() }
    }
}

@Composable
private fun RafikiApp() {
    val context = LocalContext.current
    val store = remember { Store(context) }
    var dark by remember { mutableStateOf(store.loadSettings().first) }
    var activeEngine by remember { mutableStateOf(store.loadSettings().second) }
    val chats = remember { mutableStateListOf<Chat>().apply { addAll(store.loadChats().ifEmpty { listOf(newChat()) }) } }
    val knowledge = remember { mutableStateListOf<KnowledgeChunk>().apply { addAll(store.loadKnowledge().ifEmpty { seedKnowledge() }) } }
    val memory = remember { mutableStateListOf<MemoryItem>().apply { addAll(store.loadMemory()) } }
    val services = remember { mutableStateListOf<RafikiService>().apply { addAll(store.loadServices()) } }
    val engines = remember { mutableStateListOf<RafikiEngine>().apply { addAll(store.loadEngines()) } }
    var selectedChatId by remember { mutableStateOf(chats.first().id) }
    var page by remember { mutableStateOf("chat") }
    var drawer by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }

    fun persistAll() {
        store.saveChats(chats); store.saveKnowledge(knowledge); store.saveMemory(memory); store.saveServices(services); store.saveEngines(engines); store.saveSettings(dark, activeEngine)
    }
    LaunchedEffect(dark, activeEngine) { store.saveSettings(dark, activeEngine) }

    val selectedChat = chats.firstOrNull { it.id == selectedChatId } ?: chats.first()

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Surface(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxSize()) {
                if (drawer) {
                    SideDrawer(
                        chats = chats,
                        selectedChatId = selectedChatId,
                        onSelectChat = { selectedChatId = it; page = "chat"; drawer = false },
                        onNewChat = { val c = newChat(); chats.add(0, c); selectedChatId = c.id; page = "chat"; drawer = false; persistAll() },
                        onDelete = { id -> chats.removeAll { it.id == id }; if (chats.isEmpty()) chats.add(newChat()); selectedChatId = chats.first().id; persistAll() },
                        page = page,
                        onPage = { page = it; drawer = false },
                        dark = dark,
                        onDark = { dark = !dark; persistAll() }
                    )
                }
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    when (page) {
                        "chat" -> ChatScreen(selectedChat, knowledge, memory, services, engines, activeEngine, onMenu = { drawer = true }, onSend = { text ->
                            val userMsg = ChatMessage("user", text); selectedChat.messages.add(userMsg); if (selectedChat.messages.size == 1) selectedChat.title = text.take(28)
                            val reply = localAnswer(text, knowledge, memory, services, engines, activeEngine); selectedChat.messages.add(ChatMessage("assistant", reply)); persistAll()
                        }, onToast = { toast = it })
                        "learn" -> LearnScreen(context, knowledge, onLearned = { persistAll(); toast = "تم تعلم الملف وحفظه محليًا" })
                        "memory" -> MemoryScreen(memory, onChanged = { persistAll() })
                        "services" -> ManagerScreen(false, services, engines, activeEngine, onActiveEngine = { activeEngine = it; persistAll() }, onChanged = { persistAll() })
                        "engines" -> ManagerScreen(true, services, engines, activeEngine, onActiveEngine = { activeEngine = it; persistAll() }, onChanged = { persistAll() })
                        "studio" -> DrawingStudio(onToast = { toast = it })
                        "settings" -> SettingsScreen(dark, activeEngine, engines, onDark = { dark = it; persistAll() }, onEngine = { activeEngine = it; persistAll() }, onExport = {
                            store.exportAll()
                        }, onImport = { json -> store.importAll(json); toast = "تم الاستيراد؛ أغلق وافتح القسم لمراجعة البيانات" })
                        "share" -> ScreenShareInfo()
                        else -> ChatScreen(selectedChat, knowledge, memory, services, engines, activeEngine, onMenu = { drawer = true }, onSend = { text -> selectedChat.messages.add(ChatMessage("user", text)); selectedChat.messages.add(ChatMessage("assistant", localAnswer(text, knowledge, memory, services, engines, activeEngine))); persistAll() }, onToast = { toast = it })
                    }
                }
            }
        }
        LaunchedEffect(toast) {
            if (toast != null) { kotlinx.coroutines.delay(1800); toast = null }
        }
        if (toast != null) SnackbarHost(Modifier.fillMaxSize(), toast!!)
    }
}

@Composable
private fun SideDrawer(
    chats: List<Chat>, selectedChatId: String, onSelectChat: (String) -> Unit, onNewChat: () -> Unit, onDelete: (String) -> Unit,
    page: String, onPage: (String) -> Unit, dark: Boolean, onDark: () -> Unit
) {
    Surface(Modifier.width(300.dp).fillMaxHeight(), tonalElevation = 3.dp) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(4.dp)) {
                Text("رفيقي AI", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onDark) { Icon(if (dark) Icons.Default.LightMode else Icons.Default.LightMode, "الوضع") }
            }
            Button(onClick = onNewChat, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("محادثة جديدة") }
            Spacer(Modifier.height(12.dp))
            DrawerItem("المحادثة", Icons.Default.Chat, page == "chat") { onPage("chat") }
            DrawerItem("تعلّم من ملف", Icons.Default.FileUpload, page == "learn") { onPage("learn") }
            DrawerItem("الذاكرة", Icons.Default.Memory, page == "memory") { onPage("memory") }
            DrawerItem("الخدمات", Icons.Default.Build, page == "services") { onPage("services") }
            DrawerItem("العقول والمحركات", Icons.Default.Psychology, page == "engines") { onPage("engines") }
            DrawerItem("استوديو الرسم", Icons.Default.Draw, page == "studio") { onPage("studio") }
            DrawerItem("مشاركة الشاشة", Icons.Default.Share, page == "share") { onPage("share") }
            DrawerItem("الإعدادات والنسخ الاحتياطي", Icons.Default.Settings, page == "settings") { onPage("settings") }
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Text("المحادثات", style = MaterialTheme.typography.labelLarge)
            LazyColumn(Modifier.weight(1f)) {
                items(chats, key = { it.id }) { c ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { onSelectChat(c.id) }, Modifier.weight(1f), contentPadding = PaddingValues(8.dp)) {
                            Text(c.title.ifBlank { "محادثة" }, maxLines = 1)
                        }
                        IconButton(onClick = { onDelete(c.id) }) { Icon(Icons.Default.Delete, "حذف") }
                    }
                }
            }
            Text("محلي • ذاكرة • معرفة • خدمات • محركات", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun DrawerItem(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    NavigationDrawerItem(label = { Text(title) }, icon = { Icon(icon, null) }, selected = selected, onClick = onClick, modifier = Modifier.padding(vertical = 2.dp))
}

@Composable
private fun ChatScreen(chat: Chat, knowledge: List<KnowledgeChunk>, memory: List<MemoryItem>, services: List<RafikiService>, engines: List<RafikiEngine>, activeEngine: String, onMenu: () -> Unit, onSend: (String) -> Unit, onToast: (String) -> Unit) {
    val context = LocalContext.current
    var input by remember { mutableStateOf(TextFieldValue()) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var listening by remember { mutableStateOf(false) }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeech(context) { input = TextFieldValue(it); listening = false }
        else onToast("اسمح للميكروفون من إعدادات التطبيق")
    }
    DisposableEffect(Unit) { onDispose { tts?.shutdown() } }
    LaunchedEffect(Unit) {
        tts = TextToSpeech(context) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ar") }
    }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text(chat.title, maxLines = 1) }, navigationIcon = { IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "القائمة") } })
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
            if (chat.messages.isEmpty()) {
                item { EmptyChat(activeEngine) }
            }
            items(chat.messages) { msg -> MessageBubble(msg, onSpeak = { tts?.speak(msg.text, TextToSpeech.QUEUE_FLUSH, null, "rafiki") }) }
        }
        Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                    AssistChip(onClick = { input = TextFieldValue("/تعلم") }, label = { Text("تعلّم") }, leadingIcon = { Icon(Icons.Default.Description, null) })
                    Spacer(Modifier.width(8.dp))
                    AssistChip(onClick = { input = TextFieldValue("أنشئ كود Kotlin بسيط") }, label = { Text("كود") }, leadingIcon = { Icon(Icons.Default.Code, null) })
                    Spacer(Modifier.width(8.dp))
                    AssistChip(onClick = { input = TextFieldValue("/حفظ") }, label = { Text("حفظ") }, leadingIcon = { Icon(Icons.Default.Memory, null) })
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("اسأل رفيقي…") }, maxLines = 6, shape = RoundedCornerShape(22.dp))
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = {
                        if (PackageManager.PERMISSION_GRANTED == context.checkSelfPermission(Manifest.permission.RECORD_AUDIO)) {
                            listening = true; startSpeech(context) { input = TextFieldValue(it); listening = false }
                        } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Icon(if (listening) Icons.Default.Close else Icons.Default.Mic, "الميكروفون") }
                    IconButton(onClick = {
                        val text = input.text.trim(); if (text.isNotEmpty()) { onSend(text); input = TextFieldValue() }
                    }) { Icon(Icons.Default.Send, "إرسال") }
                }
            }
        }
    }
}

@Composable
private fun EmptyChat(engine: String) {
    Column(Modifier.fillMaxWidth().padding(top = 55.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(70.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Psychology, null, Modifier.size(36.dp)) }
        Spacer(Modifier.height(16.dp))
        Text("كيف أساعدك اليوم؟", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text("العقل النشط: $engine", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        Text("تعمل المعرفة والذاكرة محليًا على الهاتف.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun MessageBubble(msg: ChatMessage, onSpeak: () -> Unit) {
    val user = msg.role == "user"
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = if (user) Arrangement.Start else Arrangement.End) {
        Surface(color = if (user) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(msg.text, modifier = Modifier.widthIn(max = 310.dp))
                if (!user) { Spacer(Modifier.width(6.dp)); IconButton(onClick = onSpeak, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.VolumeUp, "قراءة") } }
            }
        }
    }
}

private fun startSpeech(context: Context, onText: (String) -> Unit) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) return
    val r = SpeechRecognizer.createSpeechRecognizer(context)
    r.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { r.stopListening() }
        override fun onError(error: Int) { r.destroy() }
        override fun onResults(results: Bundle?) { results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText); r.destroy() }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA"); putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
    })
}

@Composable
private fun LearnScreen(context: Context, knowledge: MutableList<KnowledgeChunk>, onLearned: () -> Unit) {
    var info by remember { mutableStateOf("اختر ملفًا نصيًا أو PDF أو كودًا ليتم فهرسته محليًا.") }
    var busy by remember { mutableStateOf(false) }
    var selectedUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val picker2 = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> selectedUri = uri }
    LaunchedEffect(selectedUri) {
        val uri = selectedUri ?: return@LaunchedEffect
        val result = withContext(Dispatchers.IO) { readLearnableFile(context, uri) }
        if (result.isBlank()) info = "تعذر استخراج نص من الملف."
        else {
            val source = uri.toString()
            val parts = chunkText(result, 6000, 350)
            knowledge.addAll(parts.map { KnowledgeChunk(source, it) })
            info = "تمت إضافة ${parts.size} مقطعًا إلى المعرفة المحلية."
            onLearned()
        }
        busy = false
        selectedUri = null
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        PageHeader("تعلّم من ملف", "رفيقي يفهرس النص محليًا ويسترجع الجزء المناسب للسؤال.")
        Spacer(Modifier.height(14.dp))
        Button(onClick = { picker2.launch(arrayOf("text/*", "application/pdf", "application/json", "application/zip", "application/octet-stream", "text/html", "text/x-python")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(8.dp)); Text(if (busy) "جاري التعلم…" else "اختيار ملف") }
        Spacer(Modifier.height(10.dp))
        OutlinedCard(Modifier.fillMaxWidth()) { Text(info, Modifier.padding(14.dp)) }
        Spacer(Modifier.height(12.dp))
        Text("الدعم المدمج: TXT • MD • JSON • CSV • HTML • CSS • JS • PY • KT • JAVA • XML • PDF", style = MaterialTheme.typography.bodySmall)
    }
}

private suspend fun readLearnableFile(context: Context, uri: android.net.Uri): String {
    return withContext(Dispatchers.IO) {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val name = context.contentResolver.getType(uri).orEmpty()
            if (name == "application/pdf") readPdf(input) else input.readBytes().toString(Charsets.UTF_8)
        }.orEmpty()
    }
}

private fun readPdf(input: InputStream): String = runCatching {
    PDDocument.load(input).use { doc -> PDFTextStripper().getText(doc) }
}.getOrElse { "" }

private fun chunkText(text: String, size: Int, overlap: Int): List<String> {
    val clean = text.replace("\u0000", "").trim(); if (clean.isEmpty()) return emptyList()
    val out = mutableListOf<String>(); var start = 0
    while (start < clean.length) {
        val end = minOf(clean.length, start + size); out.add(clean.substring(start, end)); if (end == clean.length) break; start = max(start + 1, end - overlap)
    }
    return out
}

@Composable
private fun MemoryScreen(memory: MutableList<MemoryItem>, onChanged: () -> Unit) {
    var key by remember { mutableStateOf("") }; var value by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        PageHeader("الذاكرة", "بيانات صغيرة ثابتة يمكنك التحكم بها يدويًا.")
        Row(verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(key, { key = it }, Modifier.weight(1f), label = { Text("المفتاح") })
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(value, { value = it }, Modifier.weight(2f), label = { Text("القيمة") })
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = { if (key.isNotBlank() && value.isNotBlank()) { memory.removeAll { it.key == key }; memory.add(MemoryItem(key.trim(), value.trim())); key = ""; value = ""; onChanged() } }) { Icon(Icons.Default.Save, "حفظ") }
        }
        Spacer(Modifier.height(14.dp))
        LazyColumn { items(memory) { item -> Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(item.key, fontWeight = FontWeight.Bold); Text(item.value) }; IconButton(onClick = { memory.remove(item); onChanged() }) { Icon(Icons.Default.Delete, "حذف") } } } } }
    }
}

@Composable
private fun ManagerScreen(isEnginePage: Boolean, services: MutableList<RafikiService>, engines: MutableList<RafikiEngine>, activeEngine: String, onActiveEngine: (String) -> Unit, onChanged: () -> Unit) {
    var name by remember { mutableStateOf("") }; var type by remember { mutableStateOf(if (isEnginePage) "local" else "service") }; var trigger by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }; var code by remember { mutableStateOf(if (isEnginePage) "DESCRIPTION=عقل محلي\nPREFIX=بحسب المعرفة المحلية" else "REPLY=تم تنفيذ الخدمة محليًا: {input}") }
    var selected by remember { mutableStateOf(activeEngine) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        PageHeader(if (isEnginePage) "العقول والمحركات" else "الخدمات", if (isEnginePage) "تغيير العقل وإضافة محركات قابلة للتوسعة." else "إضافة خدمات محلية عبر كود آمن ومخزن في التطبيق.")
        if (isEnginePage) {
            Text("العقل النشط", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                listOf("رفيقي المحلي", "باحث المعرفة", "كاتب الأكواد").plus(engines.map { it.name }).distinct().forEach { e ->
                    FilterChip(selected == e, onClick = { selected = e; onActiveEngine(e) }, label = { Text(e) }, modifier = Modifier.padding(end = 6.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("الاسم") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(desc, { desc = it }, Modifier.fillMaxWidth(), label = { Text("الوصف") })
        Spacer(Modifier.height(8.dp))
        if (!isEnginePage) { OutlinedTextField(trigger, { trigger = it }, Modifier.fillMaxWidth(), label = { Text("الكلمات المشغلة — افصل بينها بفاصلة") }); Spacer(Modifier.height(8.dp)) }
        OutlinedTextField(code, { code = it }, Modifier.fillMaxWidth().height(150.dp), label = { Text(if (isEnginePage) "كود العقل/المحرك" else "كود الخدمة") }, maxLines = 10)
        Spacer(Modifier.height(8.dp))
        Text(if (isEnginePage) "بنية بسيطة: DESCRIPTION=… أو PREFIX=…" else "بنية بسيطة: REPLY=النص الذي سيعاد، واستخدم {input} لإدخال رسالة المستخدم." , style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
        Button(onClick = {
            if (name.isBlank()) return@Button
            if (isEnginePage) engines.add(RafikiEngine(name.trim(), type, desc.trim(), code.trim())) else services.add(RafikiService(name.trim(), trigger.trim(), code.trim()))
            name = ""; desc = ""; trigger = ""; code = if (isEnginePage) "DESCRIPTION=\nPREFIX=" else "REPLY={input}"; onChanged()
        }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text(if (isEnginePage) "إضافة عقل/محرك" else "إضافة خدمة") }
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            val list = if (isEnginePage) engines else services
            if (isEnginePage) {
                items(engines) { e -> ManagerRow(e.name, e.description, onDelete = { engines.remove(e); onChanged() }, onActivate = { onActiveEngine(e.name) }) }
            } else items(services) { s -> ManagerRow(s.name, s.trigger, onDelete = { services.remove(s); onChanged() }, onActivate = {}) }
        }
    }
}

@Composable
private fun ManagerRow(name: String, desc: String, onDelete: () -> Unit, onActivate: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(name, fontWeight = FontWeight.Bold); Text(desc.ifBlank { "بدون وصف" }, style = MaterialTheme.typography.bodySmall) }
            TextButton(onClick = onActivate) { Text("تفعيل") }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "حذف") }
        }
    }
}

@Composable
private fun DrawingStudio(onToast: (String) -> Unit) {
    var strokes by remember { mutableStateOf(listOf<List<Offset>>()) }
    var eraser by remember { mutableStateOf(false) }
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        PageHeader("استوديو الرسم", "رسم محلي بسيط وحفظ PNG على الهاتف.")
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(eraser, { eraser = !eraser }, label = { Text(if (eraser) "الممحاة" else "القلم") })
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { strokes = emptyList() }) { Icon(Icons.Default.Refresh, null); Text("مسح") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                val bitmap = Bitmap.createBitmap(1080, 1600, Bitmap.Config.ARGB_8888)
                val c = AndroidCanvas(bitmap); c.drawColor(android.graphics.Color.WHITE)
                val p = AndroidPaint().apply { color = android.graphics.Color.BLACK; strokeWidth = 8f; style = AndroidPaint.Style.STROKE; strokeCap = AndroidPaint.Cap.ROUND; isAntiAlias = true }
                strokes.forEach { pts -> if (pts.size > 1) { val path = android.graphics.Path(); path.moveTo(pts.first().x * 1080f / 360f, pts.first().y * 1600f / 700f); pts.drop(1).forEach { path.lineTo(it.x * 1080f / 360f, it.y * 1600f / 700f) }; c.drawPath(path, p) } }
                val file = File(context.getExternalFilesDir(null), "rafiki_drawing_${System.currentTimeMillis()}.png"); file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; onToast("تم حفظ الرسم: ${file.name}")
            }) { Icon(Icons.Default.Save, null); Text("حفظ PNG") }
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().weight(1f).background(Color.White).border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp)).pointerInput(eraser) {
            detectDragGestures(onDragStart = { o -> strokes = strokes + listOf(listOf(o)) }, onDrag = { _, drag -> val last = strokes.lastOrNull()?.toMutableList() ?: return@detectDragGestures; last.add(drag.position); strokes = strokes.dropLast(1) + listOf(last) })
        }) {
            Canvas(Modifier.fillMaxSize()) {
                strokes.forEach { pts -> if (pts.size > 1) { val path = Path(); path.moveTo(pts.first().x, pts.first().y); pts.drop(1).forEach { path.lineTo(it.x, it.y) }; drawPath(path, color = if (eraser) Color.White else Color.Black, style = Stroke(width = if (eraser) 28f else 6f, cap = StrokeCap.Round)) } }
            }
        }
    }
}

@Composable
private fun ScreenShareInfo() {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    val mgr = remember { context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        PageHeader("مشاركة الشاشة", "يطلب Android إذن تسجيل/مشاركة الشاشة بشكل آمن.")
        Button(onClick = { launcher.launch(mgr.createScreenCaptureIntent()) }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text("بدء طلب مشاركة الشاشة") }
        Spacer(Modifier.height(10.dp))
        Text("هذه النسخة تطلب الإذن من النظام؛ نقل الشاشة إلى شخص آخر يحتاج خدمة اتصال منفصلة.")
    }
}

@Composable
private fun SettingsScreen(dark: Boolean, activeEngine: String, engines: List<RafikiEngine>, onDark: (Boolean) -> Unit, onEngine: (String) -> Unit, onExport: () -> String, onImport: (String) -> Unit) {
    val context = LocalContext.current
    var importUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var exportText by remember { mutableStateOf<String?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val text = exportText
        if (uri != null && text != null) {
            runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } }
            exportText = null
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { importUri = it }
    LaunchedEffect(importUri) {
        val uri = importUri ?: return@LaunchedEffect
        val text = withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }.orEmpty() }
        if (text.isNotBlank()) onImport(text)
        importUri = null
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        PageHeader("الإعدادات", "كل البيانات الأساسية مخزنة محليًا على الجهاز.")
        ListItem(headlineContent = { Text("الوضع الداكن") }, supportingContent = { Text(if (dark) "مفعّل" else "غير مفعّل") }, trailingContent = { Switch(dark, onDark) })
        ListItem(headlineContent = { Text("العقل النشط") }, supportingContent = { Text(activeEngine) })
        HorizontalDivider()
        Text("النسخ الاحتياطي", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
        Button(onClick = { exportText = onExport(); exportLauncher.launch("ذاكرة_الذكاء_الاصطناعي.json") }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("تصدير ذاكرة_الذكاء_الاصطناعي.json") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/*")) }, Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("استيراد نسخة احتياطية") }
        Spacer(Modifier.height(14.dp))
        Text("المحركات المضافة: ${engines.size}", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(14.dp))
        Text("ملاحظة: لا يوجد مفتاح API داخل المشروع. النموذج التوليدي الكامل يحتاج محرك LLM منفصلًا.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun PageHeader(title: String, subtitle: String) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp)); Text(subtitle, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SnackbarHost(modifier: Modifier, text: String) {
    Box(modifier.padding(16.dp), contentAlignment = Alignment.BottomCenter) { Snackbar { Text(text) } }
}
