@ECHO OFF
REM apkit provides Gradle in its native-Android build image.
gradle %*
